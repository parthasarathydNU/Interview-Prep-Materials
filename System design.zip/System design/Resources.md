Coding challenges to build you own projects: https://codingchallenges.fyi/challenges
https://www.linkedin.com/posts/johncrickett_bad-system-for-learning-i-want-to-learn-activity-7138077016095891457-OTRJ?utm_source=share&utm_medium=member_desktop

Topics to study: 
https://github.com/ashishps1/awesome-system-design-resources

List of system design problems to prepare foarn system design 2r
(https://www.linkedin.com/posts/ashishps1_i-searched-through-internet-to-find-most-activity-7113016999437365248-4f1J?utm_source=share&utm_medium=member_ios)

https://github.com/ashishps1/awesome-system-design-resources/blob/main/README.md#system-design-interview-problems

[Blogs for learning system design](https://www.linkedin.com/posts/ryanlpeterman_27-vetted-engineering-blogs-that-will-help-activity-7113965105964339200-KvFR?utm_source=share&utm_medium=member_ios)
[Blogs to learn system design 2](https://www.linkedin.com/posts/arpit-adlakha-30691a101_github-kilimchoiengineering-blogs-a-curated-activity-7117758813612515328-Gp1m?utm_source=share&utm_medium=member_ios)


Here are Top 45 with resources to study them (for free):

1) [Design URL Shortener like TinyURL](https://www.youtube.com/watch?v=fMZMm_0ZhK4)
   [[URL Shortener]]

2) [Design Text Storage Service like Pastebin](https://www.youtube.com/watch?v=josjRSBqEBI)

3) Design Netflix: https://www.youtube.com/watch?v=psQzyFfsUGU

4) Design Youtube: https://www.youtube.com/watch?v=jPKTo1iGQiE

5) Design Instagram: https://www.youtube.com/watch?v=VJpfO6KdyWE

6) Design Twitter: https://lnkd.in/gCjEn5YT

7) Design E-commerce Store like Amazon: https://lnkd.in/gzy6wzHy

8) Design WhatsApp: https://lnkd.in/gKUheB47

9) Design Facebook: https://lnkd.in/g_yurcsQ

10) Design File Sharing System like Dropbox: https://lnkd.in/gQs2vm38

11) Design Autocomplete for Search Engines: https://lnkd.in/g-7QkTCe

12) Design Google Search: https://lnkd.in/gxt65hEW

13) Design Airbnb: https://lnkd.in/gcUQrt8R

14) Design Tinder: https://lnkd.in/grpyXJbc

15) Design Stock Exchange system: https://lnkd.in/gt_PZhzy

16) Design Google Maps: https://lnkd.in/gPjVJr2Z

17) Design Distributed Web Crawler: https://lnkd.in/gZfAzjjV

18) Design Location Based Service like Yelp: https://lnkd.in/gKAGkFBQ

19) Design Uber: https://lnkd.in/gcHvRgkY

20) Design Ticket Booking System like BookMyShow: https://lnkd.in/g3qJgG6r

21) Design Spotify: https://lnkd.in/gArruN9e

22) Design Food Delivery App like Doordash: https://lnkd.in/gGHdAa_i

23) Design Zoom: https://lnkd.in/gcJuhcMG

24) Design Shopify: https://lnkd.in/g85JfHhH

25) Design Google Docs: https://lnkd.in/gAFE7G_m

26) Design TikTok: https://lnkd.in/gT2Ju9-8

27) Design Reddit: https://lnkd.in/grGAf4dR

28) Design Code Deployment System: https://lnkd.in/gr_BJD6f

29) Design Distributed Message Queue like Kafka: https://lnkd.in/gNAeTiCP

30) Design Distributed Cloud Storage like S3: https://lnkd.in/gmFbArYt

31) Design Distributed Job Scheduler: https://lnkd.in/g6T5Dfr7

32) Design Rate Limiter: https://lnkd.in/gEFF6H_f

33) Design Distributed Locking Service: https://lnkd.in/gmx2Bhc4

34) Design Distributed key-value store: https://lnkd.in/gdYCP9w4

35) Design Distributed Cache: https://lnkd.in/gmKpA4qE

36) Design Notification Service: https://lnkd.in/gNNTUSAu

37) Design Metrics & Logging Service: https://lnkd.in/gQM7XTuh

38) Design Content Delivery Network (CDN): https://lnkd.in/gVjBNqr7

39) Design Parking Garage: https://lnkd.in/gHhe84bd

40) Design Flight Booking System: https://lnkd.in/gkVkTb65

41) Design Online Code Editor: https://lnkd.in/gRfCACAV

42) Design Vending Machine: https://lnkd.in/gyhA8QUZ

43) Design Authentication System: https://lnkd.in/gK95Y3mg

44) Design Payment System: https://lnkd.in/gBuJkXUf

45) Design UPI: https://lnkd.in/gP4AatEd

