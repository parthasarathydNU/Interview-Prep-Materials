1. Scale to support 100s of millions of daily users
2. Handle high volume of tweets, likes and retweets
3. Highly available ( 99.999 % uptime ) - accessed any time of the day
4. Security and privacy of user data
5. Incredibility low latency