### Why do we have a load balancer before the API Gateway, doesn't it make sense to have a load balancer after the API gateway ? or is this load balancer for balancing load across the various instances of the API gateway

Probably the answer is to balance the load uniformly across the various API gateway instances