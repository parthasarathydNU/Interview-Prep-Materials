1. User able to create an account and login
2. CRUD operations on tweets
3. Follow other users
4. Timeline of tweets from people they follow
5. Like reply and re tweet 
6. Search for tweets