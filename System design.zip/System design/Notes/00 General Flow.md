Each section fuels the subsequent sub section of the system design

Functional requirements ( largely and in part the non functional requirement ) inform the inputs and outputs of the system and data flow

Data flow is going to inform the high level design of the system

......

### Milestones to keep in mind based on experience level of the role

- **Mid level candidates** E4, E5 level, we should aim to reach the high level design part around the 15 minute mark
- **Senior / Staff level candidate** - 10 minutes until we reach the high level design

This way there is plenty of time to do the hight level design and deep dives

------------------------------------

Considerations: 
- CAP Theorm ?
- Read Write Ratio ?


https://excalidraw.com/#room=233632018310a6d98df3,kBsIptqcN2vqO5jsNOALiQ